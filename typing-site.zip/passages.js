/* READY-MADE MATTER
   Users see these on the typing page under "Ready-made matter".
   To add your own, copy one line below and change the 4 parts:
     id    - any short unique name, no spaces (p7, news1, law-3 ...)
     lang  - 'hi' for Hindi or 'en' for English
     title - the name users will see
     text  - the matter itself (keep it in one line inside the quotes)
   Keep a comma after every line except the last one. Save, upload, done. */
window.PASSAGES=[
{"id": "p1", "lang": "hi", "title": "पेड़ और पर्यावरण", "text": "वृक्ष हमारे जीवन के सच्चे साथी हैं। वे हमें स्वच्छ हवा, छाया, फल और लकड़ी देते हैं। वर्षा कराने में भी पेड़ों की बड़ी भूमिका होती है। जहाँ अधिक वृक्ष होते हैं, वहाँ का वातावरण शुद्ध और ठंडा रहता है। हमें हर वर्ष अधिक से अधिक पौधे लगाने चाहिए और उनकी देखभाल करनी चाहिए, ताकि आने वाली पीढ़ियों को स्वस्थ पर्यावरण मिल सके।"},
{"id": "p2", "lang": "hi", "title": "समय का महत्व", "text": "समय सबसे मूल्यवान संपत्ति है। जो बीत जाता है, वह कभी लौटकर नहीं आता। इसलिए हर काम को सही समय पर करना चाहिए। विद्यार्थी यदि नियमित रूप से अभ्यास करें तो कठिन से कठिन विषय भी आसान लगने लगता है। अनुशासन और परिश्रम से ही सफलता मिलती है। आज का काम कल पर टालने की आदत हमें पीछे धकेल देती है।"},
{"id": "p3", "lang": "hi", "title": "कंप्यूटर और टाइपिंग", "text": "आज के समय में कंप्यूटर का उपयोग लगभग हर कार्यालय में होता है। पत्र लिखना, रिकॉर्ड रखना और सूचना भेजना अब कुछ ही क्षणों में हो जाता है। इसलिए तेज़ और शुद्ध टाइपिंग का कौशल बहुत उपयोगी है। नियमित अभ्यास करने वाला व्यक्ति कम समय में अधिक काम कर सकता है और गलतियाँ भी कम करता है।"},
{"id": "p4", "lang": "en", "title": "Building a habit", "text": "A good habit is built one day at a time. Typing is no different. Ten focused minutes every morning will do more for your speed than a long session once a week. Keep your back straight, rest your wrists lightly, and look at the text rather than the keys. When you make a mistake, do not rush to hide it. Slow down for a moment, find the pattern, and try again."},
{"id": "p5", "lang": "en", "title": "An office letter", "text": "Please find attached the monthly report for the accounts section. All entries have been checked and verified by the concerned officer. If any correction is required, kindly inform this office before the end of the week so that the final statement can be prepared on time. Thank you for your continued cooperation."},
{"id": "p6", "lang": "en", "title": "The public library", "text": "Libraries have always been quiet places where people gather to learn. Today they also offer computers, free internet access and classes for people of every age. A student can prepare for an examination, a worker can learn a new skill, and a retired person can read the morning newspaper, all under one roof. A library is proof that knowledge grows when it is shared."}
];
